import tkinter as tk

def say_hello():
    label.config(text="Hello, " + entry.get() + "!")

root = tk.Tk()
root.title("Hello App")
root.geometry("300x150")

label = tk.Label(root, text="Enter your name:", font=("Segoe UI", 12))
label.pack(pady=10)

entry = tk.Entry(root, font=("Segoe UI", 12))
entry.pack()

button = tk.Button(root, text="Say Hello", command=say_hello, font=("Segoe UI", 12))
button.pack(pady=10)

root.mainloop()
