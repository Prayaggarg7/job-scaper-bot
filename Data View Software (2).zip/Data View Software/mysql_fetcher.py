"""
mssql_fetcher.py - Enhanced Version with Calendar, Role-Based Access
Professional Tkinter GUI for MSSQL data management with improved UI/UX and security
"""

import os
import json
import threading
import queue
import pyodbc
import pandas as pd
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from tkcalendar import DateEntry  # Make sure to install: pip install tkcalendar

# ---------------------------
# CONFIG
# ---------------------------
CONFIG_FILE = "db_config.json"
FILTERS_FILE = "saved_filters.json"
USER_ROLES_FILE = "user_roles.json"
DEFAULT_CONFIG = {
    "server": "",
    "database": "",
    "process_table": "ProcessDetails",
    "batch_table": "Batchcode",
    "username": "",
    "password": "",
    "trusted_connection": True,
    "driver": "{ODBC Driver 17 for SQL Server}",
    "auto_refresh": False,
    "refresh_interval": 30,  # seconds
    "admin_password": "admin123"  # Default admin password
}

# Pre-configured user database details (hardcoded for users)
USER_DB_CONFIG = {
    "server": "USER-SERVER",
    "database": "USER-DATABASE",
    "process_table": "ProcessDetails",
    "batch_table": "Batchcode",
    "username": "readonly_user",
    "password": "readonly_pass",
    "trusted_connection": False,
    "driver": "{ODBC Driver 17 for SQL Server}",
    "auto_refresh": False,
    "refresh_interval": 30
}

# Color Scheme
COLORS = {
    'primary': '#2c3e50',
    'secondary': '#34495e',
    'accent': '#3498db',
    'success': '#27ae60',
    'warning': '#f39c12',
    'danger': '#e74c3c',
    'light': '#ecf0f1',
    'dark': '#2c3e50',
    'background': '#f8f9fa',
    'surface': '#ffffff',
    'text_primary': '#2c3e50',
    'text_secondary': '#7f8c8d',
    'border': '#bdc3c7'
}

# ---------------------------
# Helper Functions
# ---------------------------
def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                cfg = json.load(f)
                for k, v in DEFAULT_CONFIG.items():
                    cfg.setdefault(k, v)
                return cfg
        except Exception:
            return DEFAULT_CONFIG.copy()
    return DEFAULT_CONFIG.copy()

def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

def load_filters():
    if os.path.exists(FILTERS_FILE):
        try:
            with open(FILTERS_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return []
    return []

def save_filters(filters):
    with open(FILTERS_FILE, "w") as f:
        json.dump(filters, f, indent=2)

def load_user_roles():
    if os.path.exists(USER_ROLES_FILE):
        try:
            with open(USER_ROLES_FILE, "r") as f:
                return json.load(f)
        except Exception:
            return {"current_role": "user", "admin_password": "admin123"}
    return {"current_role": "user", "admin_password": "admin123"}

def save_user_roles(roles):
    with open(USER_ROLES_FILE, "w") as f:
        json.dump(roles, f, indent=2)

def build_conn_str(cfg):
    if cfg.get("trusted_connection"):
        return (
            f"DRIVER={cfg.get('driver')};"
            f"SERVER={cfg.get('server')};"
            f"DATABASE={cfg.get('database')};"
            f"Trusted_Connection=yes;"
        )
    else:
        return (
            f"DRIVER={cfg.get('driver')};"
            f"SERVER={cfg.get('server')};"
            f"DATABASE={cfg.get('database')};"
            f"UID={cfg.get('username')};PWD={cfg.get('password')};"
        )

def get_connection_or_raise(cfg):
    conn_str = build_conn_str(cfg)
    return pyodbc.connect(conn_str, timeout=10)

def validate_db_config(cfg):
    """Validate if all required database fields are filled"""
    required_fields = ['server', 'database', 'process_table', 'batch_table']
    
    for field in required_fields:
        if not cfg.get(field) or not cfg.get(field).strip():
            return False, f"Missing required field: {field}"
    
    # If not using trusted connection, validate username/password
    if not cfg.get('trusted_connection', True):
        if not cfg.get('username') or not cfg.get('username').strip():
            return False, "Username is required when not using trusted connection"
        if not cfg.get('password'):
            return False, "Password is required when not using trusted connection"
    
    return True, "Valid"

# ---------------------------
# Database Operations
# ---------------------------
def fetch_records(cfg, from_date=None, to_date=None, housing=None, laser=None, fdg=None, 
                 status_filter=None, callback=None, err_callback=None):
    def worker(q_out):
        try:
            conn = get_connection_or_raise(cfg)
            table = cfg.get("process_table")
            where_clauses = []
            params = []

            if from_date:
                where_clauses.append("YourDateColumn >= ?")
                params.append(from_date)
            if to_date:
                where_clauses.append("YourDateColumn <= ?")
                params.append(to_date)
            if housing:
                where_clauses.append("HousingNo LIKE ?")
                params.append(f"%{housing}%")
            if laser:
                where_clauses.append("LaserMarking LIKE ?")
                params.append(f"%{laser}%")
            if fdg:
                where_clauses.append("FDGNumber LIKE ?")
                params.append(f"%{fdg}%")
            if status_filter:
                where_clauses.append("Status = ?")
                params.append(status_filter)

            where_sql = ""
            if where_clauses:
                where_sql = "WHERE " + " AND ".join(where_clauses)

            sql = f"SELECT * FROM {table} {where_sql} ORDER BY YourDateColumn DESC"
            cur = conn.cursor()
            cur.execute(sql, params)
            cols = [column[0] for column in cur.description]
            rows = cur.fetchall()
            conn.close()

            rows_list = [list(r) for r in rows]
            q_out.put(("ok", (cols, rows_list)))
        except Exception as e:
            q_out.put(("err", str(e)))

    q = queue.Queue()
    t = threading.Thread(target=worker, args=(q,), daemon=True)
    t.start()

    def poll():
        try:
            status, payload = q.get_nowait()
        except queue.Empty:
            root.after(100, poll)
            return
        if status == "ok":
            if callback:
                callback(payload[0], payload[1])
        else:
            if err_callback:
                err_callback(payload)

    poll()

def update_row_status(cfg, primary_key_column, primary_key_value, new_status, 
                     callback=None, err_callback=None):
    def worker(q_out):
        try:
            conn = get_connection_or_raise(cfg)
            table = cfg.get("process_table")
            sql = f"UPDATE {table} SET Status = ?, UpdatedAt = GETDATE() WHERE {primary_key_column} = ?"
            cur = conn.cursor()
            cur.execute(sql, (new_status, primary_key_value))
            conn.commit()
            conn.close()
            q_out.put(("ok", None))
        except Exception as e:
            q_out.put(("err", str(e)))

    q = queue.Queue()
    t = threading.Thread(target=worker, args=(q,), daemon=True)
    t.start()

    def poll():
        try:
            status, payload = q.get_nowait()
        except queue.Empty:
            root.after(100, poll)
            return
        if status == "ok":
            if callback: callback()
        else:
            if err_callback: err_callback(payload)

    poll()

def fetch_batch_codes(cfg, callback=None, err_callback=None):
    def worker(q_out):
        try:
            conn = get_connection_or_raise(cfg)
            table = cfg.get("batch_table")
            sql = f"SELECT * FROM {table}"
            cur = conn.cursor()
            cur.execute(sql)
            rows = cur.fetchall()
            cols = [c[0] for c in cur.description] if cur.description else []
            conn.close()
            q_out.put(("ok", (cols, rows)))
        except Exception as e:
            q_out.put(("err", str(e)))

    q = queue.Queue()
    t = threading.Thread(target=worker, args=(q,), daemon=True)
    t.start()

    def poll():
        try:
            status, payload = q.get_nowait()
        except queue.Empty:
            root.after(100, poll)
            return
        if status == "ok":
            if callback: callback(payload[0], payload[1])
        else:
            if err_callback: err_callback(payload)

    poll()

def update_batch_codes(cfg, update_dict, where_clause="", callback=None, err_callback=None):
    def worker(q_out):
        try:
            conn = get_connection_or_raise(cfg)
            table = cfg.get("batch_table")
            cols = list(update_dict.keys())
            set_sql = ", ".join([f"{c} = ?" for c in cols])
            params = [update_dict[c] for c in cols]
            sql = f"UPDATE {table} SET {set_sql} {where_clause}"
            cur = conn.cursor()
            cur.execute(sql, params)
            conn.commit()
            conn.close()
            q_out.put(("ok", None))
        except Exception as e:
            q_out.put(("err", str(e)))

    q = queue.Queue()
    t = threading.Thread(target=worker, args=(q,), daemon=True)
    t.start()

    def poll():
        try:
            status, payload = q.get_nowait()
        except queue.Empty:
            root.after(100, poll)
            return
        if status == "ok":
            if callback: callback()
        else:
            if err_callback: err_callback(payload)

    poll()

def test_connection(cfg, callback=None, err_callback=None):
    def worker(q_out):
        try:
            conn = get_connection_or_raise(cfg)
            conn.close()
            q_out.put(("ok", None))
        except Exception as e:
            q_out.put(("err", str(e)))

    q = queue.Queue()
    t = threading.Thread(target=worker, args=(q,), daemon=True)
    t.start()

    def poll():
        try:
            status, payload = q.get_nowait()
        except queue.Empty:
            root.after(100, poll)
            return
        if status == "ok":
            if callback: callback()
        else:
            if err_callback: err_callback(payload)

    poll()

# ---------------------------
# Styled Widget Classes
# ---------------------------
class StyledButton(ttk.Button):
    def __init__(self, parent, **kwargs):
        style_name = kwargs.pop('style_name', 'Primary.TButton')
        super().__init__(parent, style=style_name, **kwargs)

class StyledFrame(ttk.Frame):
    def __init__(self, parent, **kwargs):
        style_name = kwargs.pop('style_name', 'Styled.TFrame')
        super().__init__(parent, style=style_name, **kwargs)

class StyledLabel(ttk.Label):
    def __init__(self, parent, **kwargs):
        style_name = kwargs.pop('style_name', 'Styled.TLabel')
        super().__init__(parent, style=style_name, **kwargs)

# ---------------------------
# Role Management Dialog
# ---------------------------
class RoleManager:
    def __init__(self, parent, app):
        self.parent = parent
        self.app = app
        self.roles = load_user_roles()
    
    def show_role_dialog(self):
        dlg = tk.Toplevel(self.parent)
        dlg.title("Role Selection")
        dlg.geometry("400x300")
        dlg.configure(bg=COLORS['background'])
        dlg.transient(self.parent)
        dlg.grab_set()
        
        # Center window
        dlg.update_idletasks()
        x = (dlg.winfo_screenwidth() // 2) - (400 // 2)
        y = (dlg.winfo_screenheight() // 2) - (300 // 2)
        dlg.geometry(f"400x300+{x}+{y}")
        
        main_frame = StyledFrame(dlg, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        StyledLabel(main_frame, text="Select Your Role", 
                   style_name='Title.TLabel').pack(pady=20)
        
        # Current role display
        current_role_frame = StyledFrame(main_frame)
        current_role_frame.pack(fill=tk.X, pady=10)
        
        StyledLabel(current_role_frame, text="Current Role:").pack(side=tk.LEFT)
        current_role_var = tk.StringVar(value=self.roles.get('current_role', 'user').title())
        StyledLabel(current_role_frame, textvariable=current_role_var,
                   style_name='Subtitle.TLabel').pack(side=tk.LEFT, padx=5)
        
        # Role selection
        role_frame = StyledFrame(main_frame, style_name='Card.TFrame', padding=15)
        role_frame.pack(fill=tk.X, pady=10)
        
        def select_role(role):
            if role == "admin":
                self.authenticate_admin(dlg, current_role_var)
            else:
                self.set_user_role(dlg, current_role_var)
        
        StyledButton(role_frame, text="👤 User Role", 
                    command=lambda: select_role("user"),
                    width=20).pack(pady=5)
        
        StyledLabel(role_frame, text="• Read-only access\n• Pre-configured database\n• No settings modification",
                   style_name='Styled.TLabel').pack(pady=5)
        
        StyledButton(role_frame, text="👑 Admin Role", 
                    command=lambda: select_role("admin"),
                    width=20).pack(pady=5)
        
        StyledLabel(role_frame, text="• Full access\n• Database configuration\n• Settings modification",
                   style_name='Styled.TLabel').pack(pady=5)
        
        # Admin password change
        if self.roles.get('current_role') == 'admin':
            StyledButton(main_frame, text="Change Admin Password",
                       command=self.change_admin_password).pack(pady=10)
    
    def authenticate_admin(self, parent_dlg, current_role_var):
        dlg = tk.Toplevel(parent_dlg)
        dlg.title("Admin Authentication")
        dlg.geometry("350x200")
        dlg.configure(bg=COLORS['background'])
        dlg.transient(parent_dlg)
        dlg.grab_set()
        
        # Center window
        dlg.update_idletasks()
        x = (dlg.winfo_screenwidth() // 2) - (350 // 2)
        y = (dlg.winfo_screenheight() // 2) - (200 // 2)
        dlg.geometry(f"350x200+{x}+{y}")
        
        main_frame = StyledFrame(dlg, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        StyledLabel(main_frame, text="Admin Authentication", 
                   style_name='Title.TLabel').pack(pady=10)
        
        StyledLabel(main_frame, text="Enter Admin Password:").pack(anchor=tk.W, pady=5)
        password_var = tk.StringVar()
        password_entry = ttk.Entry(main_frame, textvariable=password_var, 
                                 show="*", width=25, style='Styled.TEntry')
        password_entry.pack(fill=tk.X, pady=5)
        password_entry.focus()
        
        status_label = StyledLabel(main_frame, text="")
        status_label.pack(pady=5)
        
        def verify_password():
            entered_password = password_var.get()
            stored_password = self.roles.get('admin_password', 'admin123')
            
            if entered_password == stored_password:
                self.set_admin_role(parent_dlg, current_role_var)
                dlg.destroy()
            else:
                status_label.config(text="❌ Invalid password", foreground=COLORS['danger'])
        
        btn_frame = StyledFrame(main_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        StyledButton(btn_frame, text="Authenticate", 
                   command=verify_password).pack(side=tk.RIGHT, padx=5)
        StyledButton(btn_frame, text="Cancel", 
                   command=dlg.destroy).pack(side=tk.RIGHT, padx=5)
        
        # Bind Enter key to authenticate
        password_entry.bind('<Return>', lambda e: verify_password())
    
    def set_admin_role(self, parent_dlg, current_role_var):
        self.roles['current_role'] = 'admin'
        save_user_roles(self.roles)
        current_role_var.set("Admin")
        self.app.on_role_change('admin')
        messagebox.showinfo("Role Changed", "You are now logged in as Administrator")
        parent_dlg.destroy()
    
    def set_user_role(self, parent_dlg, current_role_var):
        self.roles['current_role'] = 'user'
        save_user_roles(self.roles)
        current_role_var.set("User")
        self.app.on_role_change('user')
        messagebox.showinfo("Role Changed", "You are now logged in as User")
        parent_dlg.destroy()
    
    def change_admin_password(self):
        dlg = tk.Toplevel(self.parent)
        dlg.title("Change Admin Password")
        dlg.geometry("400x250")
        dlg.configure(bg=COLORS['background'])
        dlg.transient(self.parent)
        dlg.grab_set()
        
        # Center window
        dlg.update_idletasks()
        x = (dlg.winfo_screenwidth() // 2) - (400 // 2)
        y = (dlg.winfo_screenheight() // 2) - (250 // 2)
        dlg.geometry(f"400x250+{x}+{y}")
        
        main_frame = StyledFrame(dlg, padding=20)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        StyledLabel(main_frame, text="Change Admin Password", 
                   style_name='Title.TLabel').pack(pady=10)
        
        # Current password
        StyledLabel(main_frame, text="Current Password:").pack(anchor=tk.W, pady=2)
        current_var = tk.StringVar()
        current_entry = ttk.Entry(main_frame, textvariable=current_var, 
                                show="*", style='Styled.TEntry')
        current_entry.pack(fill=tk.X, pady=2)
        
        # New password
        StyledLabel(main_frame, text="New Password:").pack(anchor=tk.W, pady=2)
        new_var = tk.StringVar()
        new_entry = ttk.Entry(main_frame, textvariable=new_var, 
                            show="*", style='Styled.TEntry')
        new_entry.pack(fill=tk.X, pady=2)
        
        # Confirm new password
        StyledLabel(main_frame, text="Confirm New Password:").pack(anchor=tk.W, pady=2)
        confirm_var = tk.StringVar()
        confirm_entry = ttk.Entry(main_frame, textvariable=confirm_var, 
                                show="*", style='Styled.TEntry')
        confirm_entry.pack(fill=tk.X, pady=2)
        
        status_label = StyledLabel(main_frame, text="")
        status_label.pack(pady=5)
        
        def update_password():
            current = current_var.get()
            new = new_var.get()
            confirm = confirm_var.get()
            
            if current != self.roles.get('admin_password', 'admin123'):
                status_label.config(text="❌ Current password is incorrect", 
                                  foreground=COLORS['danger'])
                return
            
            if not new:
                status_label.config(text="❌ New password cannot be empty", 
                                  foreground=COLORS['danger'])
                return
            
            if new != confirm:
                status_label.config(text="❌ New passwords do not match", 
                                  foreground=COLORS['danger'])
                return
            
            self.roles['admin_password'] = new
            save_user_roles(self.roles)
            status_label.config(text="✅ Password updated successfully", 
                              foreground=COLORS['success'])
            
            # Close after success
            dlg.after(1000, dlg.destroy)
        
        btn_frame = StyledFrame(main_frame)
        btn_frame.pack(fill=tk.X, pady=10)
        
        StyledButton(btn_frame, text="Update Password", 
                   command=update_password).pack(side=tk.RIGHT, padx=5)
        StyledButton(btn_frame, text="Cancel", 
                   command=dlg.destroy).pack(side=tk.RIGHT, padx=5)

# ---------------------------
# Main Application
# ---------------------------
class MSSQLFetcherApp:
    def __init__(self, root):
        self.root = root
        self.root.title("MSSQL Data Fetcher - Professional")
        self.root.geometry("1400x800")
        self.root.configure(bg=COLORS['background'])
        
        self.cfg = load_config()
        self.user_roles = load_user_roles()
        self.current_role = self.user_roles.get('current_role', 'user')
        self.cols_var = []
        self.tree = None
        self.current_filter = {}
        self.sort_reverse = False
        self.auto_refresh_job = None
        
        # Role manager
        self.role_manager = RoleManager(root, self)
        
        # Style configuration
        self.setup_styles()
        
        # Create UI
        self.create_menu()
        self.create_toolbar()
        self.create_main_area()
        self.create_status_bar()
        
        # Keyboard shortcuts
        self.setup_shortcuts()
        
        # Apply role-based restrictions
        self.apply_role_restrictions()
        
        # Initial check
        self.root.after(500, self.on_startup_check)
        
        # Update connection status
        self.update_connection_status()

    def setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure colors for different elements
        style.configure('.', background=COLORS['background'], foreground=COLORS['text_primary'])
        
        # Frame styles
        style.configure('Toolbar.TFrame', background=COLORS['primary'], relief='raised', borderwidth=1)
        style.configure('Status.TFrame', background=COLORS['secondary'])
        style.configure('Card.TFrame', background=COLORS['surface'], relief='raised', borderwidth=1)
        style.configure('Styled.TFrame', background=COLORS['background'])
        
        # Label styles
        style.configure('Toolbar.TLabel', background=COLORS['primary'], foreground='white', font=('Segoe UI', 9))
        style.configure('Status.TLabel', background=COLORS['secondary'], foreground='white', font=('Segoe UI', 9))
        style.configure('Title.TLabel', font=('Segoe UI', 11, 'bold'), foreground=COLORS['primary'])
        style.configure('Subtitle.TLabel', font=('Segoe UI', 10, 'bold'), foreground=COLORS['secondary'])
        style.configure('Styled.TLabel', background=COLORS['background'], foreground=COLORS['text_primary'])
        
        # Button styles
        style.configure('Primary.TButton', 
                       background=COLORS['accent'],
                       foreground='white',
                       borderwidth=1,
                       focuscolor=COLORS['accent'])
        style.map('Primary.TButton',
                 background=[('active', COLORS['secondary']),
                           ('pressed', COLORS['primary'])])
        
        style.configure('Success.TButton',
                       background=COLORS['success'],
                       foreground='white')
        style.map('Success.TButton',
                 background=[('active', '#219653'),
                           ('pressed', '#1e8449')])
        
        style.configure('Danger.TButton',
                       background=COLORS['danger'],
                       foreground='white')
        style.map('Danger.TButton',
                 background=[('active', '#cb4335'),
                           ('pressed', '#a93226')])
        
        style.configure('Warning.TButton',
                       background=COLORS['warning'],
                       foreground='white')
        style.map('Warning.TButton',
                 background=[('active', '#e67e22'),
                           ('pressed', '#ca6f1e')])
        
        # Entry styles
        style.configure('Styled.TEntry', fieldbackground=COLORS['surface'], borderwidth=1, relief='solid')
        
        # Combobox styles
        style.configure('Styled.TCombobox', fieldbackground=COLORS['surface'])
        
        # Treeview styles
        style.configure('Treeview', 
                       background=COLORS['surface'],
                       foreground=COLORS['text_primary'],
                       fieldbackground=COLORS['surface'],
                       borderwidth=1,
                       relief='solid')
        
        style.configure('Treeview.Heading',
                       background=COLORS['primary'],
                       foreground='white',
                       relief='raised',
                       borderwidth=1)
        
        style.map('Treeview.Heading',
                 background=[('active', COLORS['accent'])])
        
        # Notebook styles
        style.configure('TNotebook', background=COLORS['background'])
        style.configure('TNotebook.Tab', 
                       background=COLORS['light'],
                       foreground=COLORS['text_primary'],
                       padding=[10, 5])
        style.map('TNotebook.Tab',
                 background=[('selected', COLORS['accent']),
                           ('active', COLORS['secondary'])],
                 foreground=[('selected', 'white'),
                           ('active', 'white')])

    def apply_role_restrictions(self):
        """Apply restrictions based on current role"""
        if self.current_role == 'user':
            # For users, use hardcoded configuration
            self.cfg = USER_DB_CONFIG.copy()
            self.set_status("User Mode: Using pre-configured database")

    def on_role_change(self, new_role):
        """Handle role changes"""
        self.current_role = new_role
        self.apply_role_restrictions()
        self.update_conn_label()
        self.update_connection_status()
        
        # Update UI based on role
        self.update_ui_for_role()

    def update_ui_for_role(self):
        """Update UI elements based on current role"""
        role_text = "Admin" if self.current_role == "admin" else "User"
        self.role_var.set(f"Role: {role_text}")
        
        # Update connection status label color based on role
        if self.current_role == "admin":
            self.conn_status_label.config(foreground=COLORS['warning'])
        else:
            self.conn_status_label.config(foreground=COLORS['success'])

    def create_menu(self):
        menubar = tk.Menu(self.root, bg=COLORS['primary'], fg='white', activebackground=COLORS['accent'])
        self.root.config(menu=menubar)
        
        # File menu
        file_menu = tk.Menu(menubar, tearoff=0, bg=COLORS['surface'], fg=COLORS['text_primary'])
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Export Selected (Ctrl+E)", command=self.export_selected)
        file_menu.add_command(label="Export All (Ctrl+Shift+E)", command=self.export_all)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Edit menu
        edit_menu = tk.Menu(menubar, tearoff=0, bg=COLORS['surface'], fg=COLORS['text_primary'])
        menubar.add_cascade(label="Edit", menu=edit_menu)
        if self.current_role == 'admin':
            edit_menu.add_command(label="Database Settings (Ctrl+D)", command=self.open_db_settings)
        else:
            edit_menu.add_command(label="Database Settings (Ctrl+D)", command=self.show_admin_required_message)
        edit_menu.add_command(label="Update Batch Codes (Ctrl+B)", command=self.open_batch_dialog)
        
        # View menu
        view_menu = tk.Menu(menubar, tearoff=0, bg=COLORS['surface'], fg=COLORS['text_primary'])
        menubar.add_cascade(label="View", menu=view_menu)
        view_menu.add_command(label="Refresh (F5)", command=self.refresh_data)
        view_menu.add_command(label="Clear Filters", command=self.clear_filters)
        view_menu.add_checkbutton(label="Auto Refresh", command=self.toggle_auto_refresh)
        
        # Security menu
        security_menu = tk.Menu(menubar, tearoff=0, bg=COLORS['surface'], fg=COLORS['text_primary'])
        menubar.add_cascade(label="Security", menu=security_menu)
        security_menu.add_command(label="Switch Role", command=self.role_manager.show_role_dialog)
        security_menu.add_command(label="Change Admin Password", command=self.role_manager.change_admin_password)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0, bg=COLORS['surface'], fg=COLORS['text_primary'])
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="Keyboard Shortcuts", command=self.show_shortcuts)
        help_menu.add_command(label="About", command=self.show_about)

    def create_toolbar(self):
        toolbar = StyledFrame(self.root, style_name='Toolbar.TFrame', padding=10)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        
        # Role and connection info
        info_frame = StyledFrame(toolbar, style_name='Toolbar.TFrame')
        info_frame.pack(side=tk.LEFT, padx=(4, 20))
        
        self.role_var = tk.StringVar(value=f"Role: {self.current_role.title()}")
        role_label = StyledLabel(info_frame, textvariable=self.role_var, 
                               style_name='Toolbar.TLabel')
        role_label.pack(side=tk.LEFT, padx=5)
        
        self.conn_label_var = tk.StringVar()
        self.update_conn_label()
        conn_label = StyledLabel(info_frame, textvariable=self.conn_label_var, 
                               style_name='Toolbar.TLabel')
        conn_label.pack(side=tk.LEFT, padx=5)
        
        # Buttons with icons and colors
        button_frame = StyledFrame(toolbar, style_name='Toolbar.TFrame')
        button_frame.pack(side=tk.LEFT, padx=10)
        
        StyledButton(button_frame, text="🔍 Search", command=self.open_search_dialog,
                    width=12).pack(side=tk.LEFT, padx=2)
        StyledButton(button_frame, text="🔄 Refresh", command=self.refresh_data,
                    width=12).pack(side=tk.LEFT, padx=2)
        StyledButton(button_frame, text="📤 Export", command=self.export_menu,
                    width=12).pack(side=tk.LEFT, padx=2)
        
        if self.current_role == 'admin':
            StyledButton(button_frame, text="⚙️ Settings", command=self.open_db_settings,
                        width=12).pack(side=tk.LEFT, padx=2)
        else:
            StyledButton(button_frame, text="⚙️ Settings", command=self.show_admin_required_message,
                        width=12).pack(side=tk.LEFT, padx=2)
        
        StyledButton(button_frame, text="📋 Batch Codes", command=self.open_batch_dialog,
                    width=14).pack(side=tk.LEFT, padx=2)
        
        # Quick filter section
        filter_frame = StyledFrame(toolbar, style_name='Toolbar.TFrame')
        filter_frame.pack(side=tk.RIGHT, padx=10)
        
        StyledLabel(filter_frame, text="Quick Filter:", style_name='Toolbar.TLabel').pack(
            side=tk.LEFT, padx=(20, 5))
        
        self.quick_filter_var = tk.StringVar()
        self.quick_filter_var.trace('w', self.apply_quick_filter)
        quick_filter_entry = ttk.Entry(filter_frame, textvariable=self.quick_filter_var, 
                                     width=25, style='Styled.TEntry')
        quick_filter_entry.pack(side=tk.LEFT, padx=2)
        
        # Status filter
        StyledLabel(filter_frame, text="Status:", style_name='Toolbar.TLabel').pack(
            side=tk.LEFT, padx=(10, 5))
        self.status_filter_var = tk.StringVar(value="All")
        status_combo = ttk.Combobox(filter_frame, textvariable=self.status_filter_var,
                                   values=["All", "NG", "In Process", "Completed"],
                                   width=12, state="readonly", style='Styled.TCombobox')
        status_combo.pack(side=tk.LEFT, padx=2)
        status_combo.bind("<<ComboboxSelected>>", lambda e: self.apply_status_filter())

    def create_main_area(self):
        # Main container with subtle background
        main_frame = StyledFrame(self.root, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Info bar with card style
        info_frame = StyledFrame(main_frame, style_name='Card.TFrame', padding=10)
        info_frame.pack(fill=tk.X, pady=(0, 8))
        
        self.record_count_var = tk.StringVar(value="No records loaded")
        StyledLabel(info_frame, textvariable=self.record_count_var,
                  style_name='Title.TLabel').pack(side=tk.LEFT)
        
        # Add some stats
        self.stats_var = tk.StringVar(value="")
        StyledLabel(info_frame, textvariable=self.stats_var,
                  style_name='Subtitle.TLabel').pack(side=tk.RIGHT)
        
        # Treeview with scrollbars in a card
        tree_card = StyledFrame(main_frame, style_name='Card.TFrame', padding=2)
        tree_card.pack(fill=tk.BOTH, expand=True)
        
        tree_frame = StyledFrame(tree_card)
        tree_frame.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)
        
        self.tree_scroll_y = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL)
        self.tree_scroll_x = ttk.Scrollbar(tree_frame, orient=tk.HORIZONTAL)
        
        self.tree_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)
        self.tree_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.tree = ttk.Treeview(tree_frame, show="headings",
                                yscrollcommand=self.tree_scroll_y.set,
                                xscrollcommand=self.tree_scroll_x.set,
                                selectmode='extended',
                                style='Treeview')
        self.tree.pack(fill=tk.BOTH, expand=True)
        
        self.tree_scroll_y.config(command=self.tree.yview)
        self.tree_scroll_x.config(command=self.tree.xview)
        
        # Bindings
        self.tree.bind("<Double-1>", self.on_row_double_click)
        self.tree.bind("<Return>", self.on_row_double_click)
        self.tree.bind("<Button-3>", self.show_context_menu)
        
        # Configure tags for alternating row colors with better styling
        self.tree.tag_configure('oddrow', background=COLORS['light'])
        self.tree.tag_configure('evenrow', background=COLORS['surface'])
        self.tree.tag_configure('ng', background='#ffebee')  # Light red
        self.tree.tag_configure('inprocess', background='#fff8e1')  # Light yellow
        self.tree.tag_configure('completed', background='#e8f5e8')  # Light green
        self.tree.tag_configure('selected', background=COLORS['accent'], foreground='white')

    def create_status_bar(self):
        status_frame = StyledFrame(self.root, style_name='Status.TFrame', padding=6)
        status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        
        self.status_var = tk.StringVar(value="Ready")
        StyledLabel(status_frame, textvariable=self.status_var,
                  style_name='Status.TLabel').pack(side=tk.LEFT, padx=5)
        
        # Connection status indicator
        self.conn_status_var = tk.StringVar(value="● Disconnected")
        self.conn_status_label = StyledLabel(status_frame, textvariable=self.conn_status_var,
                                           style_name='Status.TLabel')
        self.conn_status_label.pack(side=tk.RIGHT, padx=5)

    def setup_shortcuts(self):
        self.root.bind('<F5>', lambda e: self.refresh_data())
        self.root.bind('<Control-e>', lambda e: self.export_selected())
        self.root.bind('<Control-E>', lambda e: self.export_all())
        self.root.bind('<Control-d>', lambda e: self.open_db_settings() if self.current_role == 'admin' else self.show_admin_required_message())
        self.root.bind('<Control-b>', lambda e: self.open_batch_dialog())
        self.root.bind('<Control-f>', lambda e: self.open_search_dialog())
        self.root.bind('<Escape>', lambda e: self.clear_filters())

    def update_conn_label(self):
        if self.current_role == 'admin':
            server = self.cfg.get('server', '(not set)')
            db = self.cfg.get('database', '(not set)')
            table = self.cfg.get('process_table', 'ProcessDetails')
            self.conn_label_var.set(f"Server: {server} | DB: {db} | Table: {table}")
        else:
            server = USER_DB_CONFIG.get('server', 'USER-SERVER')
            db = USER_DB_CONFIG.get('database', 'USER-DATABASE')
            table = USER_DB_CONFIG.get('process_table', 'ProcessDetails')
            self.conn_label_var.set(f"Server: {server} | DB: {db} | Table: {table} (User Mode)")

    def update_connection_status(self):
        def on_success():
            self.conn_status_var.set("● Connected")
            self.conn_status_label.config(foreground='#2ecc71')  # Green
            
        def on_error(msg):
            self.conn_status_var.set("● Disconnected")
            self.conn_status_label.config(foreground=COLORS['danger'])
        
        if self.current_role == 'admin':
            # For admin, test with current configuration
            if self.cfg.get('server') and self.cfg.get('database'):
                test_connection(self.cfg, callback=on_success, err_callback=on_error)
        else:
            # For user, test with hardcoded configuration
            test_connection(USER_DB_CONFIG, callback=on_success, err_callback=on_error)

    def show_admin_required_message(self):
        messagebox.showwarning("Admin Access Required", 
                             "This feature requires Administrator privileges.\n\n"
                             "Please switch to Admin role from Security menu.")

    def open_db_settings(self):
        if self.current_role != 'admin':
            self.show_admin_required_message()
            return
            
        dlg = tk.Toplevel(self.root)
        dlg.title("Database Settings - Admin Only")
        dlg.geometry("500x500")
        dlg.configure(bg=COLORS['background'])
        dlg.transient(self.root)
        dlg.grab_set()
        
        # Center window
        dlg.update_idletasks()
        x = (dlg.winfo_screenwidth() // 2) - (500 // 2)
        y = (dlg.winfo_screenheight() // 2) - (500 // 2)
        dlg.geometry(f"500x500+{x}+{y}")
        
        notebook = ttk.Notebook(dlg)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Connection tab
        conn_frame = StyledFrame(notebook, padding=15)
        notebook.add(conn_frame, text="Connection")
        
        entries = {}
        fields = [
            ("server", "Server*"),
            ("database", "Database*"),
            ("process_table", "Process Table*"),
            ("batch_table", "Batch Table*"),
            ("username", "Username"),
            ("password", "Password"),
        ]
        
        row = 0
        for key, label_text in fields:
            StyledLabel(conn_frame, text=label_text).grid(
                row=row, column=0, sticky=tk.W, padx=5, pady=8)
            ent = ttk.Entry(conn_frame, width=35, style='Styled.TEntry')
            ent.grid(row=row, column=1, padx=5, pady=8, sticky=tk.EW)
            ent.insert(0, self.cfg.get(key, ""))
            if key == "password":
                ent.config(show="*")
            entries[key] = ent
            row += 1
        
        conn_frame.grid_columnconfigure(1, weight=1)
        
        trusted_var = tk.BooleanVar(value=self.cfg.get("trusted_connection", True))
        ttk.Checkbutton(conn_frame, text="Use Windows Trusted Connection",
                       variable=trusted_var).grid(row=row, column=0, columnspan=2,
                                                 sticky=tk.W, padx=5, pady=8)
        
        # Settings tab
        settings_frame = StyledFrame(notebook, padding=15)
        notebook.add(settings_frame, text="Settings")
        
        auto_refresh_var = tk.BooleanVar(value=self.cfg.get("auto_refresh", False))
        ttk.Checkbutton(settings_frame, text="Enable Auto Refresh",
                       variable=auto_refresh_var).pack(anchor=tk.W, pady=5)
        
        StyledLabel(settings_frame, text="Refresh Interval (seconds):").pack(
            anchor=tk.W, pady=5)
        refresh_spin = ttk.Spinbox(settings_frame, from_=10, to=300, width=10)
        refresh_spin.set(self.cfg.get("refresh_interval", 30))
        refresh_spin.pack(anchor=tk.W, padx=20, pady=5)
        
        # Test connection button
        test_status_var = tk.StringVar(value="")
        test_label = StyledLabel(settings_frame, textvariable=test_status_var)
        test_label.pack(pady=10)
        
        def test_conn():
            temp_cfg = self.cfg.copy()
            for k in ["server", "database", "process_table", "batch_table", "username", "password"]:
                temp_cfg[k] = entries[k].get().strip()
            temp_cfg["trusted_connection"] = trusted_var.get()
            
            # Validate configuration before testing
            is_valid, message = validate_db_config(temp_cfg)
            if not is_valid:
                test_status_var.set(f"❌ {message}")
                test_label.config(foreground=COLORS['danger'])
                return
            
            test_status_var.set("Testing...")
            test_label.config(foreground=COLORS['accent'])
            
            def on_ok():
                test_status_var.set("✓ Connection successful!")
                test_label.config(foreground=COLORS['success'])
            
            def on_err(msg):
                test_status_var.set(f"✗ Connection failed: {msg}")
                test_label.config(foreground=COLORS['danger'])
            
            test_connection(temp_cfg, callback=on_ok, err_callback=on_err)
        
        StyledButton(settings_frame, text="Test Connection",
                   command=test_conn).pack(pady=5)
        
        # Buttons
        btn_frame = StyledFrame(dlg)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
        
        def save_and_close():
            temp_cfg = self.cfg.copy()
            for k in ["server", "database", "process_table", "batch_table", "username", "password"]:
                temp_cfg[k] = entries[k].get().strip()
            temp_cfg["trusted_connection"] = trusted_var.get()
            temp_cfg["auto_refresh"] = auto_refresh_var.get()
            temp_cfg["refresh_interval"] = int(refresh_spin.get())
            
            # Validate configuration before saving
            is_valid, message = validate_db_config(temp_cfg)
            if not is_valid:
                messagebox.showerror("Validation Error", 
                                   f"Cannot save configuration:\n{message}\n\n"
                                   "Please fill all required fields (*).")
                return
            
            # Save configuration
            self.cfg = temp_cfg
            save_config(self.cfg)
            self.update_conn_label()
            self.update_connection_status()
            
            if self.cfg["auto_refresh"]:
                self.start_auto_refresh()
            else:
                self.stop_auto_refresh()
            
            messagebox.showinfo("Settings Saved", "Database settings saved successfully!")
            dlg.destroy()
        
        StyledButton(btn_frame, text="Save", command=save_and_close).pack(
            side=tk.RIGHT, padx=5)
        StyledButton(btn_frame, text="Cancel", command=dlg.destroy).pack(
            side=tk.RIGHT, padx=5)

    def open_search_dialog(self):
        dlg = tk.Toplevel(self.root)
        dlg.title("Advanced Search")
        dlg.geometry("650x550")
        dlg.configure(bg=COLORS['background'])
        dlg.transient(self.root)
        dlg.grab_set()
        
        # Center window
        dlg.update_idletasks()
        x = (dlg.winfo_screenwidth() // 2) - (650 // 2)
        y = (dlg.winfo_screenheight() // 2) - (550 // 2)
        dlg.geometry(f"650x550+{x}+{y}")
        
        notebook = ttk.Notebook(dlg)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Search criteria tab
        search_frame = StyledFrame(notebook, padding=15)
        notebook.add(search_frame, text="Search Criteria")
        
        # Date range with calendar widgets
        StyledLabel(search_frame, text="Date Range", style_name='Subtitle.TLabel').grid(
            row=0, column=0, columnspan=3, sticky=tk.W, pady=(0, 10))
        
        StyledLabel(search_frame, text="From Date:").grid(
            row=1, column=0, sticky=tk.W, padx=5, pady=5)
        
        from_date_frame = StyledFrame(search_frame)
        from_date_frame.grid(row=1, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=5)
        
        from_calendar = DateEntry(from_date_frame, width=20, background=COLORS['accent'],
                                 foreground='white', borderwidth=2, date_pattern='yyyy-mm-dd')
        from_calendar.pack(side=tk.LEFT, padx=5)
        
        # Set default from date to 30 days ago
        default_from_date = datetime.now() - timedelta(days=30)
        from_calendar.set_date(default_from_date)
        
        StyledLabel(search_frame, text="To Date:").grid(
            row=2, column=0, sticky=tk.W, padx=5, pady=5)
        
        to_date_frame = StyledFrame(search_frame)
        to_date_frame.grid(row=2, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=5)
        
        to_calendar = DateEntry(to_date_frame, width=20, background=COLORS['accent'],
                               foreground='white', borderwidth=2, date_pattern='yyyy-mm-dd')
        to_calendar.pack(side=tk.LEFT, padx=5)
        
        # Set default to date to today
        to_calendar.set_date(datetime.now())
        
        # Search fields
        StyledLabel(search_frame, text="Search Fields", style_name='Subtitle.TLabel').grid(
            row=3, column=0, columnspan=3, sticky=tk.W, pady=(15, 10))
        
        StyledLabel(search_frame, text="Housing No:").grid(
            row=4, column=0, sticky=tk.W, padx=5, pady=5)
        housing_ent = ttk.Entry(search_frame, width=30, style='Styled.TEntry')
        housing_ent.grid(row=4, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=5)
        
        StyledLabel(search_frame, text="Laser Marking No:").grid(
            row=5, column=0, sticky=tk.W, padx=5, pady=5)
        laser_ent = ttk.Entry(search_frame, width=30, style='Styled.TEntry')
        laser_ent.grid(row=5, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=5)
        
        StyledLabel(search_frame, text="FDG No:").grid(
            row=6, column=0, sticky=tk.W, padx=5, pady=5)
        fdg_ent = ttk.Entry(search_frame, width=30, style='Styled.TEntry')
        fdg_ent.grid(row=6, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=5)
        
        StyledLabel(search_frame, text="Status:").grid(
            row=7, column=0, sticky=tk.W, padx=5, pady=5)
        status_var = tk.StringVar(value="All")
        status_combo = ttk.Combobox(search_frame, textvariable=status_var,
                                   values=["All", "NG", "In Process", "Completed"],
                                   width=27, state="readonly", style='Styled.TCombobox')
        status_combo.grid(row=7, column=1, columnspan=2, sticky=tk.EW, padx=5, pady=5)
        
        search_frame.grid_columnconfigure(1, weight=1)
        
        # Saved filters tab
        saved_frame = StyledFrame(notebook, padding=15)
        notebook.add(saved_frame, text="Saved Filters")
        
        filters_list = tk.Listbox(saved_frame, height=10, bg=COLORS['surface'], 
                                fg=COLORS['text_primary'], selectbackground=COLORS['accent'])
        filters_list.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # Load saved filters
        saved_filters = load_filters()
        for f in saved_filters:
            filters_list.insert(tk.END, f.get('name', 'Unnamed'))
        
        def load_saved_filter():
            sel = filters_list.curselection()
            if not sel:
                messagebox.showinfo("No Selection", "Please select a filter to load")
                return
            filter_data = saved_filters[sel[0]]
            
            # Set from date
            if filter_data.get('from_date'):
                try:
                    from_calendar.set_date(datetime.strptime(filter_data.get('from_date'), '%Y-%m-%d'))
                except:
                    pass
            
            # Set to date
            if filter_data.get('to_date'):
                try:
                    to_calendar.set_date(datetime.strptime(filter_data.get('to_date'), '%Y-%m-%d'))
                except:
                    pass
            
            housing_ent.delete(0, tk.END)
            housing_ent.insert(0, filter_data.get('housing', ''))
            laser_ent.delete(0, tk.END)
            laser_ent.insert(0, filter_data.get('laser', ''))
            fdg_ent.delete(0, tk.END)
            fdg_ent.insert(0, filter_data.get('fdg', ''))
            status_var.set(filter_data.get('status', 'All'))
            notebook.select(0)  # Switch to search tab
        
        def delete_saved_filter():
            sel = filters_list.curselection()
            if not sel:
                return
            if messagebox.askyesno("Confirm", "Delete this saved filter?"):
                del saved_filters[sel[0]]
                save_filters(saved_filters)
                filters_list.delete(sel[0])
        
        btn_frame_saved = StyledFrame(saved_frame)
        btn_frame_saved.pack(fill=tk.X)
        StyledButton(btn_frame_saved, text="Load", command=load_saved_filter).pack(
            side=tk.LEFT, padx=5)
        StyledButton(btn_frame_saved, text="Delete", command=delete_saved_filter).pack(
            side=tk.LEFT, padx=5)
        
        # Status and buttons
        status_lbl = StyledLabel(dlg, text="")
        status_lbl.pack(pady=5)
        
        btn_frame = StyledFrame(dlg)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
        
        def save_current_filter():
            name = simpledialog.askstring("Save Filter", "Enter filter name:")
            if not name:
                return
            filter_data = {
                'name': name,
                'from_date': from_calendar.get_date().strftime('%Y-%m-%d'),
                'to_date': to_calendar.get_date().strftime('%Y-%m-%d'),
                'housing': housing_ent.get().strip(),
                'laser': laser_ent.get().strip(),
                'fdg': fdg_ent.get().strip(),
                'status': status_var.get()
            }
            saved_filters.append(filter_data)
            save_filters(saved_filters)
            messagebox.showinfo("Saved", f"Filter '{name}' saved successfully!")
        
        def on_submit():
            fr = from_calendar.get_date().strftime('%Y-%m-%d')
            to = to_calendar.get_date().strftime('%Y-%m-%d')
            housing = housing_ent.get().strip() or None
            laser = laser_ent.get().strip() or None
            fdg = fdg_ent.get().strip() or None
            status_val = None if status_var.get() == "All" else status_var.get()
            
            status_lbl.config(text="Searching...", foreground=COLORS['accent'])
            self.set_status("Searching database...")
            
            def on_success(columns, rows):
                status_lbl.config(text=f"✓ Found {len(rows)} records", foreground=COLORS['success'])
                self.populate_table(columns, rows)
                self.current_filter = {
                    'from_date': fr, 'to_date': to, 'housing': housing,
                    'laser': laser, 'fdg': fdg, 'status': status_val
                }
                self.set_status(f"Loaded {len(rows)} records")
                dlg.destroy()
            
            def on_error(msg):
                status_lbl.config(text=f"✗ Error: {msg}", foreground=COLORS['danger'])
                self.set_status("Search failed")
                messagebox.showerror("Database Error", str(msg))
            
            # Use appropriate configuration based on role
            config_to_use = self.cfg if self.current_role == 'admin' else USER_DB_CONFIG
            fetch_records(config_to_use, from_date=fr, to_date=to, housing=housing,
                        laser=laser, fdg=fdg, status_filter=status_val,
                        callback=on_success, err_callback=on_error)
        
        StyledButton(btn_frame, text="Save Filter", command=save_current_filter).pack(
            side=tk.LEFT, padx=5)
        StyledButton(btn_frame, text="Search", command=on_submit).pack(
            side=tk.RIGHT, padx=5)
        StyledButton(btn_frame, text="Cancel", command=dlg.destroy).pack(
            side=tk.RIGHT, padx=5)

    def populate_table(self, columns, rows):
        self.cols_var = columns
        
        # Clear existing
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Configure columns
        self.tree['columns'] = columns
        for col in columns:
            self.tree.heading(col, text=col, command=lambda c=col: self.sort_by_column(c))
            self.tree.column(col, width=150, anchor=tk.W)
        
        # Insert rows with styling
        status_counts = {'NG': 0, 'In Process': 0, 'Completed': 0}
        
        for idx, row in enumerate(rows):
            tags = ['oddrow' if idx % 2 else 'evenrow']
            
            # Add status-based tags and count
            if 'Status' in columns:
                status_idx = columns.index('Status')
                status = str(row[status_idx]).lower()
                if 'ng' in status:
                    tags.append('ng')
                    status_counts['NG'] += 1
                elif 'process' in status:
                    tags.append('inprocess')
                    status_counts['In Process'] += 1
                elif 'complete' in status:
                    tags.append('completed')
                    status_counts['Completed'] += 1
            
            self.tree.insert("", tk.END, values=row, tags=tags)
        
        # Update stats
        stats_text = f"NG: {status_counts['NG']} | In Process: {status_counts['In Process']} | Completed: {status_counts['Completed']}"
        self.stats_var.set(stats_text)
        self.record_count_var.set(f"Total Records: {len(rows)}")
        self.set_status(f"Loaded {len(rows)} records")

    def sort_by_column(self, col):
        # Get data
        data = [(self.tree.set(item, col), item) for item in self.tree.get_children('')]
        
        # Sort
        try:
            data.sort(reverse=self.sort_reverse, key=lambda t: float(t[0]))
        except ValueError:
            data.sort(reverse=self.sort_reverse, key=lambda t: t[0].lower())
        
        # Rearrange items
        for idx, (val, item) in enumerate(data):
            self.tree.move(item, '', idx)
        
        self.sort_reverse = not self.sort_reverse

    def apply_quick_filter(self, *args):
        if not self.tree or not self.cols_var:
            return
        
        search_text = self.quick_filter_var.get().lower()
        
        # Show all if empty
        if not search_text:
            for item in self.tree.get_children():
                self.tree.reattach(item, '', 'end')
            return
        
        # Filter rows
        visible_count = 0
        for item in self.tree.get_children():
            values = self.tree.item(item)['values']
            match = any(search_text in str(val).lower() for val in values)
            if match:
                self.tree.reattach(item, '', 'end')
                visible_count += 1
            else:
                self.tree.detach(item)
        
        self.set_status(f"Showing {visible_count} filtered records")

    def apply_status_filter(self):
        if not self.current_filter:
            messagebox.showinfo("No Data", "Please perform a search first")
            return
        
        status_val = self.status_filter_var.get()
        if status_val == "All":
            status_val = None
        
        self.current_filter['status'] = status_val
        self.refresh_data()

    def clear_filters(self):
        self.quick_filter_var.set("")
        self.status_filter_var.set("All")
        if self.tree:
            for item in self.tree.get_children():
                self.tree.reattach(item, '', 'end')
        self.set_status("Filters cleared")

    def refresh_data(self):
        if not self.current_filter:
            messagebox.showinfo("No Search", "Please perform a search first")
            return
        
        self.set_status("Refreshing...")
        
        def on_success(columns, rows):
            self.populate_table(columns, rows)
            self.set_status(f"Refreshed - {len(rows)} records")
        
        def on_error(msg):
            self.set_status("Refresh failed")
            messagebox.showerror("Error", str(msg))
        
        # Use appropriate configuration based on role
        config_to_use = self.cfg if self.current_role == 'admin' else USER_DB_CONFIG
        fetch_records(config_to_use, 
                     from_date=self.current_filter.get('from_date'),
                     to_date=self.current_filter.get('to_date'),
                     housing=self.current_filter.get('housing'),
                     laser=self.current_filter.get('laser'),
                     fdg=self.current_filter.get('fdg'),
                     status_filter=self.current_filter.get('status'),
                     callback=on_success, err_callback=on_error)

    def export_menu(self):
        menu = tk.Menu(self.root, tearoff=0, bg=COLORS['surface'], fg=COLORS['text_primary'])
        menu.add_command(label="Export Selected Rows", command=self.export_selected)
        menu.add_command(label="Export All Rows", command=self.export_all)
        menu.post(self.root.winfo_pointerx(), self.root.winfo_pointery())

    def export_selected(self):
        if not self.tree:
            messagebox.showwarning("No Data", "No data loaded")
            return
        
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("No Selection", "Please select rows to export")
            return
        
        rows = [self.tree.item(iid)['values'] for iid in sel]
        self._do_export(rows, "selected")

    def export_all(self):
        if not self.tree:
            messagebox.showwarning("No Data", "No data loaded")
            return
        
        rows = [self.tree.item(iid)['values'] for iid in self.tree.get_children()]
        self._do_export(rows, "all")

    def _do_export(self, rows, export_type):
        if not rows:
            messagebox.showinfo("No Data", "No rows to export")
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        default_name = f"export_{export_type}_{timestamp}.xlsx"
        
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            initialfile=default_name,
            filetypes=[("Excel files", "*.xlsx"), ("CSV files", "*.csv"), ("All files", "*.*")]
        )
        
        if not path:
            return
        
        try:
            df = pd.DataFrame(rows, columns=self.cols_var)
            
            if path.endswith('.csv'):
                df.to_csv(path, index=False)
            else:
                df.to_excel(path, index=False, engine='openpyxl')
            
            messagebox.showinfo("Success", f"Exported {len(df)} rows to:\n{path}")
            self.set_status(f"Exported {len(df)} rows")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    def open_batch_dialog(self):
        dlg = tk.Toplevel(self.root)
        dlg.title("Update Batch Codes")
        dlg.geometry("600x500")
        dlg.configure(bg=COLORS['background'])
        dlg.transient(self.root)
        dlg.grab_set()
        
        # Center window
        dlg.update_idletasks()
        x = (dlg.winfo_screenwidth() // 2) - (600 // 2)
        y = (dlg.winfo_screenheight() // 2) - (500 // 2)
        dlg.geometry(f"600x500+{x}+{y}")
        
        entries = {}
        status_lbl = StyledLabel(dlg, text="Loading batch codes...", foreground=COLORS['accent'])
        status_lbl.pack(pady=10)
        
        # Create scrollable frame
        canvas = tk.Canvas(dlg, bg=COLORS['background'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(dlg, orient="vertical", command=canvas.yview)
        scrollable_frame = StyledFrame(canvas, padding=15)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        def on_fetch(cols, rows):
            if not rows:
                status_lbl.config(text="No batch data found", foreground=COLORS['danger'])
                return
            
            row = rows[0]
            col_map = dict(zip(cols, row))
            batch_cols = [c for c in cols if c.lower().startswith("batch")]
            
            if not batch_cols:
                status_lbl.config(text="No Batch columns found", foreground=COLORS['danger'])
                return
            
            status_lbl.config(text=f"Editing {len(batch_cols)} batch codes", foreground=COLORS['success'])
            
            # Create grid of entries
            for i, c in enumerate(batch_cols):
                frame = StyledFrame(scrollable_frame, style_name='Card.TFrame', padding=10)
                frame.pack(fill=tk.X, pady=5, padx=5)
                
                StyledLabel(frame, text=f"{c}:", style_name='Subtitle.TLabel').pack(
                    anchor=tk.W)
                ent = ttk.Entry(frame, width=40, style='Styled.TEntry', font=('Segoe UI', 10))
                ent.pack(fill=tk.X, pady=5)
                ent.insert(0, str(col_map.get(c, "")))
                entries[c] = ent
            
            canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y, pady=10)
            
            # Buttons
            btn_frame = StyledFrame(dlg)
            btn_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
            
            def do_submit():
                upd = {k: entries[k].get().strip() for k in entries}
                
                # Validation
                for k, v in upd.items():
                    if not v:
                        messagebox.showwarning("Validation", f"{k} cannot be empty")
                        return
                
                status_lbl.config(text="Updating...", foreground=COLORS['accent'])
                
                def on_ok():
                    messagebox.showinfo("Success", "Batch codes updated successfully!")
                    dlg.destroy()
                
                def on_err(m):
                    status_lbl.config(text="Update failed", foreground=COLORS['danger'])
                    messagebox.showerror("Error", str(m))
                
                # Use appropriate configuration based on role
                config_to_use = self.cfg if self.current_role == 'admin' else USER_DB_CONFIG
                update_batch_codes(config_to_use, upd, where_clause="",
                                 callback=on_ok, err_callback=on_err)
            
            StyledButton(btn_frame, text="Update All", command=do_submit).pack(
                side=tk.RIGHT, padx=5)
            StyledButton(btn_frame, text="Cancel", command=dlg.destroy).pack(
                side=tk.RIGHT, padx=5)
        
        def on_err(m):
            status_lbl.config(text=f"Error: {m}", foreground=COLORS['danger'])
            messagebox.showerror("Error", str(m))
        
        # Use appropriate configuration based on role
        config_to_use = self.cfg if self.current_role == 'admin' else USER_DB_CONFIG
        fetch_batch_codes(config_to_use, callback=on_fetch, err_callback=on_err)

    def on_row_double_click(self, event):
        if not self.tree:
            return
        
        sel = self.tree.focus()
        if not sel:
            return
        
        values = self.tree.item(sel)['values']
        cols = self.cols_var
        
        # Find primary key
        primary_key_column = None
        for c in ['ID', 'Id', 'id', 'PrimaryKey', cols[0]]:
            if c in cols:
                primary_key_column = c
                break
        
        if not primary_key_column:
            primary_key_column = cols[0]
        
        primary_key_value = values[cols.index(primary_key_column)]
        
        self.show_detail_dialog(cols, values, primary_key_column, primary_key_value, sel)

    def show_detail_dialog(self, cols, values, pk_col, pk_val, tree_item):
        dlg = tk.Toplevel(self.root)
        dlg.title(f"Record Details - {pk_val}")
        dlg.geometry("1200x700")
        dlg.configure(bg=COLORS['background'])
        dlg.attributes("-topmost", True)
        
        # Center window
        dlg.update_idletasks()
        x = (dlg.winfo_screenwidth() // 2) - (1200 // 2)
        y = (dlg.winfo_screenheight() // 2) - (700 // 2)
        dlg.geometry(f"1200x700+{x}+{y}")
        
        # Header with card style
        header = StyledFrame(dlg, style_name='Card.TFrame', padding=15)
        header.pack(fill=tk.X, padx=10, pady=10)
        StyledLabel(header, text=f"Record ID: {pk_val}",
                  style_name='Title.TLabel').pack(side=tk.LEFT)
        
        # Main content area with scrollbar
        main_frame = StyledFrame(dlg, padding=10)
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        canvas = tk.Canvas(main_frame, bg=COLORS['background'], highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = StyledFrame(canvas, padding=10)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Create 3-column layout
        n = len(cols)
        group_size = (n + 2) // 3
        
        col_frames = []
        for i in range(3):
            f = StyledFrame(scrollable_frame, style_name='Card.TFrame', padding=10)
            f.grid(row=0, column=i, sticky="nsew", padx=5, pady=5)
            scrollable_frame.grid_columnconfigure(i, weight=1)
            col_frames.append(f)
        
        for idx, col in enumerate(cols):
            group = idx // group_size
            if group >= 3:
                group = 2
            
            # Field frame
            field_frame = StyledFrame(col_frames[group], style_name='Styled.TFrame')
            field_frame.pack(fill=tk.X, pady=8)
            
            StyledLabel(field_frame, text=f"{col}:",
                      style_name='Subtitle.TLabel').pack(anchor=tk.W)
            
            val_text = str(values[idx]) if values[idx] is not None else ""
            val_label = StyledLabel(field_frame, text=val_text,
                                  font=('Segoe UI', 10),
                                  wraplength=350)
            val_label.pack(anchor=tk.W, padx=10, pady=(2, 5))
            
            ttk.Separator(col_frames[group], orient='horizontal').pack(
                fill=tk.X, pady=2)
        
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Action buttons
        btn_frame = StyledFrame(dlg, style_name='Card.TFrame', padding=15)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, padx=10, pady=10)
        
        StyledLabel(btn_frame, text="Update Status:",
                  style_name='Subtitle.TLabel').pack(side=tk.LEFT, padx=10)
        
        def mark_status(new_status):
            def on_ok():
                messagebox.showinfo("Updated", f"Status changed to: {new_status}")
                # Update tree view
                if "Status" in cols:
                    status_idx = cols.index("Status")
                    new_vals = list(values)
                    new_vals[status_idx] = new_status
                    self.tree.item(tree_item, values=new_vals)
                dlg.destroy()
            
            def on_err(m):
                messagebox.showerror("Error", str(m))
            
            # Use appropriate configuration based on role
            config_to_use = self.cfg if self.current_role == 'admin' else USER_DB_CONFIG
            update_row_status(config_to_use, pk_col, pk_val, new_status,
                            callback=on_ok, err_callback=on_err)
        
        StyledButton(btn_frame, text="✗ NG Pallet", style_name='Danger.TButton',
                  command=lambda: mark_status("NG")).pack(side=tk.LEFT, padx=5)
        StyledButton(btn_frame, text="⏸ In Process", style_name='Warning.TButton',
                  command=lambda: mark_status("In Process")).pack(side=tk.LEFT, padx=5)
        StyledButton(btn_frame, text="✓ Completed", style_name='Success.TButton',
                  command=lambda: mark_status("Completed")).pack(side=tk.LEFT, padx=5)
        StyledButton(btn_frame, text="Close", command=dlg.destroy).pack(
            side=tk.RIGHT, padx=5)

    def show_context_menu(self, event):
        if not self.tree:
            return
        
        item = self.tree.identify_row(event.y)
        if not item:
            return
        
        self.tree.selection_set(item)
        
        menu = tk.Menu(self.root, tearoff=0, bg=COLORS['surface'], fg=COLORS['text_primary'])
        menu.add_command(label="View Details", command=lambda: self.on_row_double_click(event))
        menu.add_command(label="Copy Value", command=self.copy_cell_value)
        menu.add_separator()
        menu.add_command(label="Mark as NG", command=lambda: self.quick_status_update("NG"))
        menu.add_command(label="Mark as In Process",
                        command=lambda: self.quick_status_update("In Process"))
        menu.add_command(label="Mark as Completed",
                        command=lambda: self.quick_status_update("Completed"))
        menu.add_separator()
        menu.add_command(label="Export Selected", command=self.export_selected)
        
        menu.post(event.x_root, event.y_root)

    def copy_cell_value(self):
        if not self.tree:
            return
        
        sel = self.tree.focus()
        if not sel:
            return
        
        col = self.tree.identify_column(self.tree.winfo_pointerx() - self.tree.winfo_rootx())
        col_idx = int(col.replace('#', '')) - 1
        
        if col_idx >= 0:
            values = self.tree.item(sel)['values']
            value = str(values[col_idx])
            self.root.clipboard_clear()
            self.root.clipboard_append(value)
            self.set_status(f"Copied: {value}")

    def quick_status_update(self, new_status):
        sel = self.tree.selection()
        if not sel:
            return
        
        if len(sel) > 1:
            if not messagebox.askyesno("Confirm", 
                f"Update status to '{new_status}' for {len(sel)} records?"):
                return
        
        # Find primary key column
        cols = self.cols_var
        pk_col = None
        for c in ['ID', 'Id', 'id', cols[0]]:
            if c in cols:
                pk_col = c
                break
        
        updated = 0
        for item in sel:
            values = self.tree.item(item)['values']
            pk_val = values[cols.index(pk_col)]
            
            def on_ok(item=item, values=values):
                nonlocal updated
                updated += 1
                if "Status" in cols:
                    status_idx = cols.index("Status")
                    new_vals = list(values)
                    new_vals[status_idx] = new_status
                    self.tree.item(item, values=new_vals)
            
            # Use appropriate configuration based on role
            config_to_use = self.cfg if self.current_role == 'admin' else USER_DB_CONFIG
            update_row_status(config_to_use, pk_col, pk_val, new_status, callback=on_ok)
        
        self.set_status(f"Updated {updated} records")

    def toggle_auto_refresh(self):
        if self.cfg.get("auto_refresh"):
            self.stop_auto_refresh()
            self.cfg["auto_refresh"] = False
        else:
            self.start_auto_refresh()
            self.cfg["auto_refresh"] = True
        save_config(self.cfg)

    def start_auto_refresh(self):
        if self.auto_refresh_job:
            return
        
        interval = self.cfg.get("refresh_interval", 30) * 1000
        
        def auto_refresh():
            if self.current_filter:
                self.refresh_data()
            self.auto_refresh_job = self.root.after(interval, auto_refresh)
        
        self.auto_refresh_job = self.root.after(interval, auto_refresh)
        self.set_status(f"Auto-refresh enabled ({self.cfg.get('refresh_interval')}s)")

    def stop_auto_refresh(self):
        if self.auto_refresh_job:
            self.root.after_cancel(self.auto_refresh_job)
            self.auto_refresh_job = None
            self.set_status("Auto-refresh disabled")

    def set_status(self, message):
        self.status_var.set(message)

    def show_shortcuts(self):
        shortcuts = """
Keyboard Shortcuts:

F5                  - Refresh data
Ctrl+F              - Open search dialog
Ctrl+E              - Export selected rows
Ctrl+Shift+E        - Export all rows
Ctrl+D              - Database settings (Admin only)
Ctrl+B              - Update batch codes
Esc                 - Clear filters
Enter               - View row details (when row selected)
        """
        messagebox.showinfo("Keyboard Shortcuts", shortcuts)

    def show_about(self):
        about_text = f"""
MSSQL Data Fetcher - Professional Version

A professional database management tool with:
• Advanced search and filtering
• Export to Excel/CSV
• Batch updates
• Auto-refresh capability
• Keyboard shortcuts
• Modern UI/UX
• Role-based access control

Current Role: {self.current_role.title()}

Version 2.0 - Enhanced with Role-Based Security
        """
        messagebox.showinfo("About", about_text)

    def on_startup_check(self):
        # Show role selection dialog on first startup
        if not self.cfg.get("server") and self.current_role == 'admin':
            if messagebox.askyesno("Setup Required",
                "Database connection not configured.\n\nWould you like to set it up now?"):
                self.open_db_settings()

# ---------------------------
# Main Entry Point
# ---------------------------
if __name__ == "__main__":
    # Install required packages if not already installed
    try:
        from tkcalendar import DateEntry
    except ImportError:
        print("Please install required packages:")
        print("pip install tkcalendar pandas pyodbc openpyxl")
        exit(1)
    
    root = tk.Tk()
    app = MSSQLFetcherApp(root)
    root.mainloop()